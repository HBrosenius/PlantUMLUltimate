# Lesson 13: Component diagrams

Explain the portal's deployment or service structure in a readable diagram.

Start and recorded-result sources are chapter snapshots from the demonstrations. Open the appropriate diagram type, then paste the source. A snapshot is plain PlantUML, not a replacement for a connected portable document or its history. Follow the video for UI-only and local-state workflows.
