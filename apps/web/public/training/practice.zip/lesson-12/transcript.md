# Lesson 12: Class diagrams

## 1. Model types, members and relationships

A Class diagram describes types and the relationships between them. It helps you explain a domain model or an interface design, rather than the order of one request. Our example has Customer, Request, RequestStatus and a repository interface. You will add an entity, inspect structured members, review relationship choices, organize types and apply a shared style. Keep the level of detail appropriate for the audience: not every implementation field needs to appear in an explanatory model.

## 2. Add an entity with the right kind

Use Insert and Class, interface, or enum to create AuditRecord. Inspect the kind options before adding it. A class, abstract class, interface, enumeration and annotation carry different meanings. Give the type a clear name and use an alias where it makes source references easier. After creation, inspect the generated declaration and the rendered object. Adding a type is only the beginning; its members and relationships should explain the responsibility you intend it to have.

## 3. Inspect the entity and its members

Select Customer to open the entity inspector. Identity includes the type kind, name, alias and generic type information. The Members section presents fields and operations rather than forcing you to treat the entire declaration as one opaque label. Review visibility, static and abstract modifiers alongside the actual member meaning. Presentation and package placement are separate choices. Make a small, intentional change and check the source rather than editing several unrelated properties before reviewing the result.

## 4. Fields and operations are structured information

A field describes stored or exposed state; a method describes an operation. In the inspector, use the structured member controls to distinguish these kinds and review their visibility and type. We will add a description field and an assignment operation to Request using the structured controls. Inspect the source and then the entity. Keep the declaration readable: a useful model tells the reader what the type is responsible for, not just how many members were copied from an implementation.

## 5. Use parameter and type information precisely

The assignment operation takes an agent identifier and returns no value. A parameter name and its type communicate different facts, just as a method name differs from its return type. Use type completion and structured controls where available, then inspect the resulting declaration. For generic types or specialized syntax, source remains the precise editing path. A completion suggestion is a convenience, not evidence that the chosen type is semantically right for the model.

## 6. Create a method parameter in the structured editor

Select Request and add a method named assignTo with return type void. Use the new method row to add a parameter. Enter agentId as its name and UUID as its type, then click outside the parameter group to commit and inspect the resulting declaration in source. The parameter type and return type describe different parts of the operation. Reveal the member in source and verify that its enclosing class remains intact. Choose types that express your domain; a completion list is an editing aid, not a design decision.

## 7. Choose and inspect relationships

The associations and dependency in this model express different connections. Customer submits requests, Request uses a status, and the repository depends on Request as a parameter type. Open the relationship tool to inspect available endpoint, kind, label and multiplicity choices. Choose a relation because it describes the responsibility or ownership you mean, not because its arrow happens to look familiar. Reconnect mistaken endpoints and verify the source after an identity change.

## 8. Create and undo a typed relationship

Use a small proposal to check a relationship before keeping it. Choose the repository as the source, the status type as the target and dependency as the relationship. Label it filters by, add it and inspect the authored arrow and current preview. The label explains the proposed contract; decide whether that contract fits the types in your model. Shared Undo removes this relationship as one authored change, leaving the original domain model intact.

## 9. Packages, notes and layout

A package or namespace groups related types. Notes explain an important assumption without turning a class name into a paragraph. The reference example places a note beside Request to explain stable identity. Open package and note creation, then inspect Diagram settings. Keep grouping consistent with the abstraction you are teaching: a domain package, a code namespace and a deployment boundary are not automatically the same thing. Layout should support the relationship story without inventing new semantics.

## 10. Apply a deliberate bulk style

Use modifier selection to choose Customer and Request together. Inspect the bulk panel and apply a supported shared style. The style can distinguish domain types from infrastructure interfaces, but labels and relationship meaning must remain understandable without color alone. When copying or duplicating model elements, inspect the identifiers, members and connections in the result. Use the source diff or Undo when the operation includes more than you intended.

## 11. Describe a small domain

Pause and add the audit record class, then give Request a description field and an assignment operation with a typed parameter. Explain the status enumeration and repository interface in your own words. Review one relationship endpoints and multiplicity, add a useful note, and apply a shared style to a selected pair of entities. A successful result makes the type responsibilities and relationships clear without requiring the reader to reconstruct the implementation from a cluttered drawing.

## 12. Keep structure and behavior distinct

Use Class diagrams for types, members and structural relationships. Use Sequence or Activity diagrams when the important question is behavioral flow. The common editing pattern remains the same: create or select an object, inspect supported properties, and check the source and rendered result. The next lesson moves outward from types to components and infrastructure, while retaining that habit of separating identity, meaning and presentation.
