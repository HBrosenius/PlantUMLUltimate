# Lesson 20: Export and final handover

Deliver the final document, plaintext source, and a readable exported diagram.

Start and recorded-result sources are chapter snapshots from the demonstrations. Open the appropriate diagram type, then paste the source. A snapshot is plain PlantUML, not a replacement for a connected portable document or its history. Follow the video for UI-only and local-state workflows.
