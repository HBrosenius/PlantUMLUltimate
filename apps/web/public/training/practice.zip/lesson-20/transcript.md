# Lesson 20: Export and final handover

## 1. Deliver a usable result

A useful handover gives the recipient the right artifact and enough context to use it. A portable document supports continued editing; plain Plant UML source supports text based reuse; images and PDF support reading and presentation. We will preview and download the supported image formats, inspect encoded renderer links, and create local presentation views and review notes. Finish by checking the files you intend to deliver.

## 2. Preview and download SVG

Open File, Export and Preview export. Select SVG and inspect the full drawing, margin and background. SVG is useful when a recipient needs a scalable diagram. The export includes the rendered image rather than editor selections and interaction overlays. Check long labels, clipping and authored appearance in the preview before downloading. Keep the file alongside the document so the recipient can distinguish the readable picture from the editable project.

## 3. Choose a practical raster scale

Choose PNG for a raster image that can be inserted into many documents. Raster scale changes pixel dimensions and memory use. Increase it only as far as the intended output requires, then inspect readability and the estimated image size. Choose a suitable margin and background. If the app reports an image size limit, reduce scale or use SVG rather than repeatedly attempting an oversized export.

## 4. Understand the PDF output

Select PDF and review its page and image bounds. This PDF output uses a white page with a rasterized diagram, so it is different from a vector SVG. Check the result at the reading size the recipient will use. A very wide schedule may be better shared as a scalable image or the portable document as well. Download the PDF after checking the preview, and include a clear title and revision context in the handover.

## 5. Keep source and copy formats clear

File Export also provides plain source and clipboard formats. Plain source is useful for text workflows, but it does not replace a connected portable document with retained application information. Copy as Markdown and Copy for Confluence prepare content for their destination; review what was copied before pasting it into a shared page. Copying and preparing content do not publish it. Keep private or unfinished work in your practice environment until the intended handover is ready.

## 6. Download the authored source

Export Source to obtain the plain Plant UML text for the active diagram. Download it and compare it with the authored statements. The source is useful for text workflows and other compatible renderers, but it does not carry the complete application document, connected members or retained history. Keep the portable project as well when the recipient needs to continue the full application workflow. Check which diagram member is active before exporting.

## 7. Verify Markdown and Confluence clipboard output

Copy as Markdown prepares a fenced Plant UML code block. After copying, inspect the actual clipboard content in this training preview. Copy for Confluence prepares the corresponding wiki macro markup; inspect that content too before pasting it into the destination. These commands prepare text, and do not publish a page or send a message. Keep source disclosure and destination permissions in mind when moving a real project into another system.

## 8. Verify a copied image

Copy image prepares a rendered picture for a destination that accepts images. Choose the command from File and Export, then inspect the actual PNG read from the clipboard in this training preview. Check the dimensions and that all task labels and the milestone are visible. A copied image is a snapshot; it does not carry the editable document, history or connected diagram members. Keep the portable source alongside a shared picture when the recipient needs to continue editing.

## 9. Encoded links disclose their source

Link and embed creates an encoded source URL, not a collaboration invitation. Encoding is not encryption: someone with the URL can recover the source. Opening or embedding that URL sends the source to the chosen renderer, and external rendering can differ from this app's local preview. Review the renderer address and disclosure before generating a link. Generating the text locally does not mean the eventual image is an offline artifact.

## 10. Present a focused view

Open Presentation and local review from View. Presentation gives the diagram a read only stage with navigation and review tools. Use Fit and zoom for the audience rather than changing task dates to fit a screen. Open the local review panel to choose diagram objects and add highlight steps. A focused explanation should guide the audience through a few meaningful objects, not animate every item simply because it is available.

## 11. Present connected diagram members

Open presentation from a connected document rather than a separate diagram. Use its diagram selector to move between the work breakdown structure and the linked schedule. Fit the selected diagram for the audience and confirm which member is being presented. Presentation navigation changes the view, while the connected document retains the authored member sources and links. Return to the editor when you need to change the plan.

## 12. Keep local views and notes in context

Use a view name to save a meaningful sequence of highlight steps. Choose an object, write a personal review note and anchor it to that object. These views and notes are stored locally in the browser. They are not included in the portable file, exports or live collaboration. Another person will not receive them automatically. Include the required explanation explicitly in your handover, and revisit an anchor if the underlying diagram changes.

## 13. Verify and open rendered links

Rendered links are working controls, so review their destinations before opening them. Activate the Portal reference and check the browser confirmation. Cancel this first request and verify that the diagram and source remain unchanged. Accept the second request to open the reference in a separate tab without replacing the editor. The exported SVG also retains the link destination; check the actual artifact when preparing a handover. Web links and mail links use the confirmation guard, while cross diagram member connections and collaboration invitations remain separate features.

## 14. Verify the final package

Finish with a portable project, the required plain source and readable exported diagrams. Reopen the project and inspect connected members, labels, schedule assumptions and retained history. Open the images and PDF at their intended reading size. Include the project start date, status date and important assumptions so a reader can interpret the plan. Document limitations honestly; Jira is excluded from this edition. A good handover makes the next person's first action clear.
