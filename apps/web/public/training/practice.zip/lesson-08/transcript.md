# Lesson 08: WBS structure

## 1. Describe what the project delivers

A work breakdown structure organizes scope into a hierarchy of deliverables and work packages. It answers what is included before you decide all the dates. Our portal example has discovery, design, implementation, testing and release branches. In this lesson you will add and edit nodes, move a whole subtree, choose branch presentation, create a relationship, and style a selection. Keep the distinction between scope structure and schedule logic in mind; the connected Gantt workflow comes next.

## 2. Read the hierarchy

Each extra hierarchy marker places a node one level deeper. The source makes the parent-child structure visible as text, while the diagram makes it easier to discuss. Select Discovery and identify its interviews and requirements children. A parent label should describe a coherent part of the work. Avoid turning the hierarchy into a list of unrelated status notes, and remember that rearranging the scope does not by itself assign dates or prove dependencies between all its leaves.

## 3. Add a work package

Use Insert and WBS node to add another package. Give it an outcome-oriented label, such as Support training, and review where it belongs in the structure. A new node should have a meaningful parent rather than appearing wherever there happened to be space on the canvas. Inspect the resulting source markers and the drawing. Later, when we link this WBS to a Gantt chart, those scope decisions will help us identify missing scheduled work.

## 4. Edit a label and branch side

Select Discovery and change its label to Discover customer needs. Leave the field to apply the edit. The node keeps its children, so a clearer label does not require rebuilding the branch. Branch side changes where work appears around the parent. Move this branch to the left and compare the source and preview. Use side and color choices to improve readability, but keep the hierarchy itself responsible for explaining which work belongs together.

## 5. Move the whole subtree

Dragging a node onto the middle of another node nests the complete subtree under that target. Dropping above or below reorders, and dropping to the sides changes branch presentation. Move Discovery into Design in this disposable example and inspect the children afterward. Interviews and requirements should travel with their parent. Use Undo when the new grouping does not express the intended scope. A good hierarchy is one you can explain, not simply a symmetrical arrangement of boxes.

## 6. Reorder with the keyboard

The WBS also supports keyboard interaction. Focus a node and use the supported alternate-arrow movement to reorder siblings. Here we move Design upward among its siblings, then inspect the source order. Keyboard focus matters: a shortcut inside a text field edits that field rather than moving a diagram node. Use the diagram's focusable controls deliberately, and return to Help when you need the exact shortcut for your platform and current editor.

## 7. Connect related work

A WBS relationship expresses an additional connection beyond the tree hierarchy. Focus Discovery and start keyboard connection mode with C, then focus Implementation and press Enter. Inspect the new arrow and generated source. You can also use the selected node's connection handle. Keep this meaning separate from parenthood: adding an arrow does not move a node into another branch. When links later map to scheduling dependencies, review any mappings that cannot be represented safely.

## 8. Style several nodes together

Select Discovery and Design with a modifier so both belong to the selection. The bulk panel lists operations supported by the selected objects. Apply one shared style and inspect the source changes. Bulk operations are useful for consistent presentation, but review which objects are included before copying or duplicating a selection. Use labels and structure to communicate meaning as well as color, and avoid treating a styling change as progress or schedule information.

## 9. Create and reorganize a branch

Pause and add a Support training work package to the appropriate branch. Rename one parent for clarity, move a subtree, and confirm that its children remain attached. Create one additional relationship and explain how it differs from the tree. Finally, apply a shared style to two nodes and inspect the changed source. Your success check is semantic: the work is organized under sensible parents and the additional connection has a clear purpose.

## 10. Connect scope to delivery next

You can now maintain the WBS as a structured model rather than a static picture. Read the hierarchy, edit nodes, move subtrees, use keyboard controls, and review extra relationships. The next lesson places diagrams inside one portable document and connects WBS work to a Gantt schedule. We will then check coverage so that a work package is not silently missing from the delivery plan.
