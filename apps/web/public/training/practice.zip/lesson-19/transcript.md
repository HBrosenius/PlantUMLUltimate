# Lesson 19: Saving, recovery, and offline use

## 1. Choose the right safeguard

Saving, browser recovery and version history protect different parts of your work. A portable pumlu document retains application information that plain Plant UML source does not contain. Browser recovery helps you return to a workspace, while a saved file gives you an explicit copy you can manage. We will save and reopen a practice document, inspect compression and history limits, and review password protection, recovery, offline use and mobile editing.

## 2. Save through the browser fallback

Choose Save as from File and save a portable practice document. In this recording, the browser uses its download fallback. A browser with native file access may instead let you choose a writable file and save subsequent edits directly. Check the filename and the app's saved state rather than assuming that a download updated an older copy. Keep one clear working copy and avoid accidentally continuing in a stale duplicate.

## 3. Reopen and verify

Save the document, then open that saved file through File and Open. The fallback uses a file selection control. Verify the task labels, durations and current preview after loading it. For a connected project, also verify member diagrams and links. Reopening is a useful check before handing over or deleting a temporary copy. A file with the expected name is only useful when it contains the expected state.

## 4. Save and reopen with the macOS picker

These screenshots show the actual macOS file picker workflow in Chrome. Choose Save as, select your working folder, enter a clear file name and press Save. Back in the app, check the file name and the Saved to file indicator. To verify the saved copy, choose Open and select the same portable document in the operating system picker. After reopening, we verified that Design still lasts five days and that the diagram preview is current. The file picker appearance and available permissions depend on your browser and operating system.

## 5. Compression and history limits

Open Document settings. Gzip compression reduces the portable file size; None keeps the uncompressed representation. Inspect Maximum versions and History budget before changing retention. A larger history budget is not a substitute for named checkpoints and saved copies. For this practice, keep the recommended compression and review the limits without reducing them. Apply a setting only when you understand its effect on the document you will save.

## 6. Understand password protection

Enable Password protection in Document settings to reveal the password controls and guidance. There is no password recovery. Use a password you can retain securely, and enter the same value in confirmation before applying it to a practice copy. Encrypted unsaved changes remain only in the session, while collaboration and plaintext exports are not end to end encrypted. Cancel this inspection to keep the starting file unprotected; the next exercise creates a separate protected practice copy.

## 7. Save and unlock a protected practice copy

Now apply password protection to a disposable practice file. We use an explicitly public training password only for this example; choose and retain your own password for real work. Enter and confirm it, apply the setting and save the portable document. Reopen the saved copy, enter the password when prompted and verify the expected source and current preview. A successful unlock confirms this copy can be recovered with that password. Keep the original unencrypted practice file separately.

## 8. Recovery and workspace backups

Browser recovery can restore recent workspace state, but it depends on the browser and its stored data. Clearing site data or changing browser profiles can remove that safeguard. Inspect the workspace backup and restore commands in File and keep an explicit backup before a major reorganization. A backup, portable document and plain source export serve different recovery needs. Practice restoration in a separate disposable workspace before relying on it during an incident.

## 9. Restore a workspace backup

Create a workspace backup before experimenting with a disposable plan. Change Design from five to seven days so the working copy differs from that backup. Choose Workspace restore and select the saved backup, then read the browser replacement confirmation before accepting. Restore the practice workspace and verify that Design is five days again. The app downloads a backup of the previous tabs, but preserve anything useful before accepting replacement. This exercise proves the recovery path with a small known state rather than waiting for an incident.

## 10. Handle external changes deliberately

When native file access is available, another application may change the same file. Read the external change warning and compare the file with your current work before choosing a reload or overwrite path. Preserve a separate copy if both versions contain useful edits. Download fallback copies do not behave like a continuously linked native file, so manage their names and locations deliberately. The earlier saving exercise uses download fallback; a later controlled file-handle exercise demonstrates the conflict review without showing the operating system picker.

## 11. Prepare offline use before you need it

Visit and load the application online before expecting an installed or cached copy to start offline. Check the browser's install option where supported, then test the complete workflow on your device without a connection. Local editing and rendering do not make remote collaboration, Jira or external renderer links available offline. Reconnect before using those services. The next demonstration uses a production build served locally to test cached startup, editing, rendering and saving with its network disabled.

## 12. Restart the cached app offline

This demonstration uses a production build served locally, with its actual service worker and cached assets. Wait until caching is ready, then disable this browser session’s network and reload the application. Verify the restored plan and current preview. Change Design from five days to six while still offline, then save a portable copy. Finally restore the connection. This proves local startup, rendering, editing and saving for this browser session; remote collaboration, Jira and external renderer links still require their services.

## 13. Install the desktop app and apply an update

These screenshots show Chrome installing the local training build as a desktop app. Check the site identity, choose Next and confirm Install in the browser prompt. The installed app opens in its own window with the saved practice document and current preview. For this controlled update exercise, we served a new service worker revision with the same application assets. When Update available appears, save your work and select that button to activate the waiting update and reload. After the reload, verify the saved file indicator, the five day Design task and the current diagram preview. This verifies the desktop workflow on this Mac; physical mobile installation remains untested because no device is available.

## 14. Use the mobile task view

On a narrow screen, use the task view for practical schedule updates and inspect the selected task carefully before changing it. A compact view helps with labels, progress and supported task fields, while a larger workspace remains useful for complex source and relationship review. Verify the result and save through the file workflow supported by the device. Test the exact mobile browser you plan to use rather than assuming its file access is identical to a desktop browser.

## 15. Update a task in a narrow-screen browser

Open the same practice plan in a separate browser session at a mobile-sized viewport. The mobile task list lets you search and choose work before opening its properties. Select Design and inspect the progress and resource controls. Make a small progress update, apply it and verify the result in the task list. This is a real responsive browser session, not a scaled desktop screenshot. Test file saving and installation on the physical device you plan to use, because browser capabilities can differ.

## 16. Review an externally changed file handle

This controlled exercise uses a real browser File System file handle with a browser-managed training file. The operating system picker is not being demonstrated; the exercise supplies that handle so we can inspect saving and conflict behavior. Save the portable document through the file-handle path, then modify the stored file outside the diagram editor. Attempt Save and inspect the external-file conflict review before choosing a result. For this disposable example, reload the external version and verify its six day Design duration, then save the verified result through the handle. Test the actual operating system picker separately in your supported browser.

## 17. Test your recovery routine

Pause and save a practice document, reopen it and verify its contents. Create a named checkpoint and a workspace backup. Inspect the compression and retention settings. In a separate copy, test password protection and unlock with a securely retained password. Finally test offline startup and mobile saving on the devices you will actually use. Record which checks passed and keep a known good portable copy before continuing.
