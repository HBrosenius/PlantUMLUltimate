# Lesson 03: Gantt tasks and progress

Build a small launch plan with a release milestone and progress values.

Start and recorded-result sources are chapter snapshots from the demonstrations. Open the appropriate diagram type, then paste the source. A snapshot is plain PlantUML, not a replacement for a connected portable document or its history. Follow the video for UI-only and local-state workflows.
