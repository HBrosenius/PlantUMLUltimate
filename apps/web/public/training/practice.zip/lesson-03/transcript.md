# Lesson 03: Gantt tasks and progress

## 1. Build a plan you can maintain

In this lesson we will build and maintain the work in a Gantt plan. You will create a task, edit its details, move and resize work, and represent progress. We will also add a milestone, organize rows, and change several tasks together. Finally, we will inspect what happens to dependent work when a predecessor is deleted. Work with a disposable practice copy so that the examples can be repeated and compared.

## 2. Create a task with a real start

Use Insert and choose Task to create another activity. Give the task a specific outcome: in our example, acceptance testing. Enter three working days and choose a fixed start date. Alternatively, select a predecessor when the work should follow another task. A dependency takes precedence over a fixed start in this creation dialog. After adding the task, check both its bar and its source statement. Naming the work clearly makes later dependency and resource discussions easier.

## 3. Edit a task and its effort

Select Design to open its inspector. The name is what the reader sees, while the alias in the source remains a useful stable reference. Rename the displayed work to Interaction design and set its duration to six working days. Move focus out of a valid field to apply the change. Keep the source visible while you work. A label change should not require you to reconstruct every relationship manually, and a duration change should not be confused with a simple zoom operation.

## 4. Move work deliberately

For an independently dated task, dragging horizontally changes its start. Moving a task that drives other work can also affect downstream dates, so pay attention to the move policy and any review offered by the app. In this example the dates are explicit, making the movement easy to inspect. Select Design, move it a short distance, and read the resulting start in the inspector. Use Undo if the move does not represent the intended scheduling decision.

## 5. Resize duration rather than the view

Dragging a task's right edge changes its duration. That is different from dragging the body to move the start, and different again from preview zoom. Resize Design and then open its inspector to read the resulting duration. Working calendars can make the bar span more calendar days than the effort number suggests. When precision matters, enter the required number directly after the visual adjustment. Confirm the authored statement before moving on to the next operation.

## 6. Move, resize and reorder with the keyboard

For this independent-task practice, set the move policy to Only task. Focus Design and use Alt plus Right Arrow to request a one day move, then inspect its resulting dates. Alt plus Shift plus Right Arrow increases its duration by one day. Control plus Down Arrow reorders the focused task in the authored task list. Undo those three diagram operations to return to the original source. Start a horizontal drag, then hold Shift to snap pointer movement to weeks. Read the new task dates in the inspector and check the current preview after the edit.

## 7. Record progress explicitly

Progress describes how much work is completed; it is not a replacement for dates or effort. Select Build and enter twenty five percent in Progress. Leave the field, then inspect the bar and the new source statement. Use an agreed reporting practice when updating percentages, especially when several people contribute to one task. A progress value by itself does not explain whether the remaining work is realistic. Forecasting and status-date interpretation are taught in a later lesson.

## 8. Represent an event with a milestone

A milestone represents an event rather than a block of effort. The launch marker already follows Build's end. Add another milestone called Readiness review, using a fixed date in this example. Inspect the difference between a fixed milestone and one tied to a task's calculated start or end. The choice expresses a real planning rule: does the review have an independently committed date, or should it follow the work? Use the source and preview to check which rule you created.

## 9. Dividers, notes and row order

Horizontal dividers organize task rows into readable sections. They are useful for separating discovery, implementation and release work without pretending that a section is another task. Add a Release preparation divider at the end of the plan. Notes provide explanations that do not belong in a task name, while task links can point to relevant supporting material. Keep these annotations concise. Row ordering and same-row display improve presentation, but dependencies should still carry the actual scheduling rules.

## 10. Open a task reference without changing the plan

Task links open supporting material without changing the schedule. Activate the Design reference and review the destination in the browser confirmation. Cancel the first request, then verify that the authored source is unchanged. Open the link again and accept the destination. The reference opens in a separate tab while the original diagram stays available. Return to the diagram and confirm its current preview before continuing.

## 11. Edit several selected tasks

When the same change applies to several tasks, select them together and inspect the bulk panel. Here we select Research and Design, then examine the available fields for shifting dates, completion and resources. Enter twenty five and choose Set completion for both tasks, then inspect the source to confirm both changes. Check which tasks are included before applying it, and use the shared Undo history to reconsider the operation. Copy and Duplicate are useful for reusing structure, but inspect the generated identifiers and relationships afterward.

## 12. Copy and duplicate a task selection

Select Research and Design together and check that the panel names the intended tasks. Choose Copy and inspect the actual clipboard text in this training preview. Copy prepares reusable content without changing the authored plan. Close the clipboard preview, then choose Duplicate for the selected tasks. Inspect the new declarations and aliases in the source, and check the new tasks in the drawing. Use shared Undo to return to the original plan and verify that the original declarations remain. Reusing a selection still requires a check of identifiers, dates and relationships.

## 13. Paste selected tasks into another practice diagram

Copy Research and Design from the selected task panel. Open a second Gantt practice tab and keep a small setup task in that diagram. Place the source cursor before the closing delimiter and paste the copied task statements, then separate the closing delimiter onto its own line. Verify that Research, Design and their dependency render in the receiving diagram alongside the setup task. Switch between the tabs to verify their independent source, and check aliases before pasting into a populated plan. Copying task statements does not copy a connected project or its document links.

## 14. Delete a predecessor and check dates

Deleting a task is a structural change, so inspect its dependents before and after. First select Build and read its start date. Then delete Design in this disposable example. Open Build again and compare its start with the value you recorded. The app preserves the dependent task's date when removing the predecessor rather than silently pulling all following work to the beginning of the plan. Inspect the rewritten source, and use Undo if deletion was not the intended change.

## 15. Shift selected tasks and assign a person

Choose the only-task movement policy before selecting Research and Design together. Shift the selected work by two days and verify that the source changes while the preview remains current. Enter Sam in the bulk Resource field and choose Assign. Confirm that both selected tasks now have Sam in their source declarations. Combined with the completion and copy examples, this demonstrates one reviewed intention applied to several selected tasks.

## 16. Delete a predecessor inside a compact arrow chain

Inspect Build and retain its resolved start before deleting a predecessor. This diagram uses a compact arrow chain as well as explicit scheduling rules. Delete Design from the inspector and compare the resulting dates. Build keeps its previous date, the tied gate is pinned to its earlier date, and the chain becomes a direct arrow from Analysis to Build. Review the source and current preview together. Use one shared Undo to recover the original tasks, compact chain and scheduling rules.

## 17. Create a small release plan

Pause and create an acceptance-testing task lasting three working days. Add a readiness milestone, organize the release work with a divider, and record twenty five percent progress for Build. Try one move and one resize, inspecting the values after each operation. Then undo those experimental changes. Your final plan should retain its meaningful dependencies and contain the new work and status you intended. Compare source and diagram rather than relying on the general shape of the bars.

## 18. A maintained plan is more than a picture

You can now create work, edit its details, record progress, and organize a readable schedule. Moving, resizing and deleting tasks change the authored plan, so check their consequences. Use milestones for events, notes for explanation, and bulk operations for a clearly defined selection. The next lesson concentrates on the rules behind the dates: dependencies, lags and working calendars. Those rules explain why a task begins where it does.
