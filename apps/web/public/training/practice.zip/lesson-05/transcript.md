# Lesson 05: People and workload

## 1. Who can do the work?

A schedule can fit its dates and still ask one person to be in two places at once. This lesson adds the people side of the plan. We will assign work, read allocation, inspect capacity and overload, and examine the relationship between effort and elapsed working time. The example deliberately gives Alice two overlapping assignments. The goal is to recognize the problem and resolve the plan rather than merely hide its warning.

## 2. Inspect an assignment

Select Design and examine its resource assignment section. Alice is assigned at one hundred percent. An allocation describes how much of that person is assigned to this task while it runs. It does not automatically prove that the person is available, and it does not change their overall capacity. Compare the assignment in the inspector with the authored resource statement. Consistent names matter: different spellings can make one real person appear as two resources in workload reporting.

## 3. Effort and elapsed time

The duration entered for assigned work represents effort in the scheduling calculation. When additional allocation is available, the same effort can occupy fewer working days. This is a planning model, not a guarantee that every task can be accelerated by adding people. Review the effective start and end as well as the authored effort. We will add another full allocation to Backend and compare the calculated result. Keep a note of the original duration so the effect is clear.

## 4. Add a second person and inspect the working duration

Inspect Backend before changing its assignments. Sam is allocated at fifty percent, with eight authored days of work. Add Alex at fifty percent and confirm both people in the source. After the preview refreshes, read the working duration and resulting dates. Verify the actual schedule rather than assuming that every additional person halves a task. Here the authored work remains eight days.

## 5. Open the workload panel

Choose Plan and then Workload. The panel groups assignments by person and compares their planned allocation with capacity. Alice appears on both Design and Frontend during the same period, so the plan asks for two hundred percent while her capacity is one hundred percent. Read the peak figure and inspect the affected dates. A red warning is a prompt to investigate the underlying assignments, not proof that increasing the capacity number is the right solution. Select Frontend in the workload panel to open its task inspector and investigate the assignment directly.

## 6. Daily and weekly views

The Summary control switches between daily and weekly workload views. Daily detail helps you locate a specific collision, while weekly grouping helps you understand a longer pattern. Inspect the tasks and overloaded dates instead of reading only one peak value. You can use task navigation and resource filtering to focus the canvas, then return to the complete plan. Remember that hiding another person's tasks from the view does not remove those assignments from the underlying schedule.

## 7. Capacity is an assumption

Capacity describes how much availability the plan allows for a resource. Change Alice's capacity to two hundred percent and observe the comparison. The calculation now treats those overlapping assignments as within the declared capacity. This is appropriate only if Alice represents a team or another resource that actually has that availability. For an individual person, a larger capacity number can conceal an unrealistic plan. Record the assumption clearly, and restore a realistic capacity before choosing how to resolve the work.

## 8. Resolve the overlap in the plan

There are several honest ways to resolve a conflict: move work, reduce the allocation and accept a longer elapsed duration, or assign an appropriate available person. Here we reassign Frontend to Alex so Alice is no longer scheduled on both tasks. Inspect the updated workload and check the other people too. Solving Alice's problem by overloading Alex would simply move the conflict. Keep the schedule consequences visible while choosing the resolution.

## 9. Warnings and calculations are separate

The Gantt preferences allow you to disable the over-allocation warning banner. That can be useful when an assignee name represents an entire team, but it does not change workload calculations or repair a scheduling conflict. Open Settings and find the warning preference. Compare this presentation choice with the resource capacities stored with the document. Be explicit about which kind of setting you changed, especially when sharing a plan with other people.

## 10. Turn assignments into a useful check-in

The workload panel can lead directly to a task check-in. This keeps the follow-up connected to the actual assignments rather than requiring you to reconstruct who owns each task. Inspect the report scope and dates before copying any message. The app prepares the content; it does not send a message to your team automatically. The reporting lesson will explain the options and other report types in detail.

## 11. Fix a real resource conflict

Pause and open the workload example. Identify the tasks that overlap for Alice and state her peak allocation and capacity. Choose one realistic resolution and explain its scheduling consequence. Then compare daily and weekly summaries and check that your change has not overloaded someone else. Finally, distinguish changing an assignment, changing capacity and hiding a warning. You have succeeded when the plan is feasible under assumptions you can explain, not simply when the screen has no red banner.

## 12. Keep assumptions visible

Assignments, capacity and working calendars together determine what the resource model says. Use the inspector for task details and the workload panel for the wider picture. Treat effort and elapsed working time as different quantities, and use warning preferences only for their intended presentation purpose. In the next lesson we will compare forecast and scenario alternatives, using the same habit of checking the assumptions before applying a proposed change.
