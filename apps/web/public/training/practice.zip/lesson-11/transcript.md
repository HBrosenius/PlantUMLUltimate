# Lesson 11: Use Case diagrams

## 1. Model capabilities and their users

A Use Case diagram explains which actors interact with a system and which capabilities the system offers. It is a view of scope and responsibility, rather than a sequence of internal implementation steps. Our customer portal lets customers submit and track requests, while a support agent resolves them. We will create objects, inspect their identity and appearance, add relationships and notes, and compare include with extend. Keep each capability meaningful to an actor.

## 2. Create another capability

Use Insert and Use case to add Read help. A good name describes an actor's goal rather than a screen widget or a database table. Review the kind, name and alias in the creation screen before adding the object. The alias is useful when you refer to this capability repeatedly in source. After creation, locate the declaration and the rendered object. We will connect capabilities separately so that adding an object is not confused with defining who can use it.

## 3. Create an actor deliberately

An actor represents a role interacting with the system, not necessarily one named person. Add an Auditor role to this practice model. Inspect the actor and use-case kind choices rather than selecting a shape only for decoration. External services can also be actors when they play a relevant role at the system boundary. Keep the diagram focused on the capabilities you are explaining, and avoid listing every internal implementation component as another actor.

## 4. Identity, appearance and placement

Select Submit request and inspect its properties. Name and alias identify the capability, while color, stereotype and the business-object option change how it is presented. The container setting places it within a system boundary or package. Keep identity changes deliberate because other statements refer to these objects. A boundary groups what belongs to the modeled system; it is not a substitute for explaining the capability itself. Review the source when moving an object between containers.

## 5. Connect actors and capabilities

Relationship tools connect the actors and capabilities you have modeled. Open the relationship creation screen and inspect the endpoint and type choices. Associations explain participation, while generalization and other relationship types express different meanings. Select endpoints deliberately and reconnect a relationship when the original endpoint was wrong. Do not compensate for an incorrect association with a misleading label. Notes can explain an assumption, but the relationship should still be semantically correct.

## 6. Include and extend are different

Paste the supplied reference example and compare its two additional relationships. Submit request includes validation as part of that capability. Attach a file extends the submission behavior under an appropriate optional condition. Include and extend are not interchangeable labels for any arrow between two ovals. Use them when you can explain the behavioral distinction in plain language, and check arrow direction and stereotype in the source. Keep the actor associations visible so the diagram still answers who needs each capability.

## 7. Add context and tune presentation

Use packages or boundaries to organize the model, and notes to record useful assumptions. Diagram settings control overall presentation, including layout choices. Open these screens and compare their purpose with the object inspector. A good system boundary keeps internal capabilities together while actors remain outside the system they use. Layout and styling should reinforce that distinction. If the valid syntax you need is not represented by a dedicated form, preserve it in source and inspect the resulting preview.

## 8. Commit a presentation setting and verify source

Open the Use Case diagram settings and change the layout direction to top to bottom. Give this review copy an explicit title and caption. These settings commit as you leave the fields; this inspector does not require the Apply button used by some other editors. Inspect the saved title and caption statements and the current preview. Use shared Undo to reconsider a committed setting rather than assuming that closing the inspector cancels it.

## 9. Style a selected category

Select Submit request and Track request together with a modifier, then inspect the bulk panel. Apply a supported shared style and check the source changes. A common style can make related capabilities easier to recognize, but retain clear names and meaningful boundaries. Copy or duplicate only a verified selection, and review resulting identifiers and associations before continuing. Shared history lets you reconsider a bulk operation without manually reversing each object.

## 10. Explain the portal scope

Pause and add an Auditor actor and a Read help capability to a practice copy. Decide whether they belong in an association and explain why. Add one useful note, then use the reference example to explain include and extend in your own words. Inspect a capability's container and apply a shared style to two selected objects. Your success check is that someone can identify the system boundary, the actors and their goals without needing to know the implementation.

## 11. Keep the actor’s goal in view

A capability model should make system scope understandable. Keep actors, use cases, boundaries and relationship meanings distinct. Inspect identity and placement before presentation, and verify associations after moving, renaming or duplicating objects. The next lesson describes the types and members inside the system, using a Class diagram to answer a different question from this actor-centered view.
