# Lesson 10: Sequence diagrams

## 1. Explain an interaction over time

A Sequence diagram explains who interacts with whom and in what order. It is useful when a component picture does not tell you how a request actually proceeds. We will model a customer submitting a request through a web app and API to a database. You will create participants and messages, inspect lifecycle and fragment controls, and review an error branch. The goal is a readable explanation of behavior, not a drawing that implies more concurrency or timing precision than the model contains.

## 2. Create and identify participants

Participants represent the actors and systems taking part in the interaction. Use Insert and Participant to add a support service. The kind can represent an actor, boundary, control, entity, database, collection or queue, depending on what you need to communicate. Use an alias when a readable display name would be cumbersome in repeated message statements. Inspect the created declaration and keep naming consistent with the other diagrams in the customer portal document.

## 3. Inspect before changing identity

Select the API participant to open its inspector. Participant settings include identity and presentation choices. Review aliases, stereotypes, colors and ordering without assuming that the visible display name is the only reference used elsewhere. This inspector applies related changes together with Apply, so it differs from a field that commits when focus leaves. Make an intentional change and check the messages afterward. Close or cancel an unneeded draft rather than leaving an unexplained pending edit.

## 4. Read and create messages

A message identifies sender, receiver and the interaction text. Use the message creation screen to review the participant pickers, message kinds and advanced modifiers. A request and a return are different parts of the story; arrow shape and direction should express your meaning consistently. Existing and newly introduced names need to be deliberate so that a typo does not create an unintended participant. Inspect a message's source statement before drawing conclusions from its position alone.

## 5. Show activation and returns

Activation represents a period of activity on a participant's lifeline. It is useful when you want to distinguish being present in an interaction from actively handling a call. Paste the supplied extended example and follow the activation of Web and API through the request. Deactivation ends those active regions. Creation, destruction, return shortcuts and message modifiers have more specialized meanings; use a small reference example to check the syntax before combining them into a complicated interaction.

## 6. Create and end a participant lifecycle

Follow the worker lifecycle in this small source example. Creation introduces Worker at its first received message, while activation marks its active work. The return statement completes the most recent active call and produces the receipt. Destruction ends the worker lifeline after release. Read these statements alongside the rendered interaction before combining them into a larger model.

## 7. Model a successful path and an error path

The combined fragment in this example separates valid and invalid requests. Read each branch condition and follow the messages within that branch. Other fragment families include optional behavior, loops, parallel work, breaks, critical regions and grouping. Choose the construct for its behavioral meaning, not just its border. The structure inspector and source show where the fragment begins, where branches change and where it ends. Keep nested fragments small enough that a reader can follow one path without guessing.

## 8. Compare fragment families with small references

An optional block represents a conditional interaction. A loop represents repeated interaction under its stated condition. Parallel branches describe concurrent work, rather than an alternative choice. A break identifies an interaction that terminates its enclosing path. A critical region identifies work that must be considered indivisible in this interaction model. A named group organizes related messages; these blocks are separate teaching examples supplied with the practice files.

## 9. Notes, references and flow controls

Notes explain assumptions or context that would make a message label too long. A reference can point to a separately described interaction. Separators, delays, spacing, duration arrows, page breaks and numbering controls each affect how the story is read. The example numbers its messages and places a note beside Web. Inspect these facilities in Insert, then choose only the ones that improve the explanation. Adding many presentation devices cannot repair an unclear interaction or a missing branch condition.

## 10. Read reference, spacing and duration source constructs

A reference names a separately described interaction contract. Separators and automatic numbering organize the message sequence. A delay and explicit spacing affect how the interaction is read, while notes retain explanatory context. Page breaks remain explicit source statements; check the page handling of your intended export. Duration anchors use the Teoz layout to mark a measured span between two points in the interaction. Inspect the source and actual preview for these constructs, and use Issues when a supported source feature has a visual-editing limitation.

## 11. Reorder and tune presentation

Participant order and message placement affect readability. Use the diagram's supported dragging or reordering controls and inspect the resulting source order. Open Diagram settings to compare alignment, wrapping, spacing, boxes and layout choices such as Teoz where supported. These settings should make the interaction easier to follow without changing its intended meaning. If a valid language construct has no dedicated visual editor, keep it in source and review the rendered result rather than promising that every syntax variant has its own form.

## 12. Reorder participants and messages deliberately

Open the reorder panel for this small interaction. Move API before Web in the participant list and inspect the declaration order and lifeline layout. Move Check attachments before Check draft in the message list. Message order changes the interaction being described, so check the authored statements and drawing together. Undo both reorder operations to recover the original sequence. Finally change the diagram title through its presentation settings and verify the committed title in source.

## 13. Style a participant selection

Use modifier selection to choose Web and API together. Inspect the bulk panel and apply a shared style. This is useful when several participants belong to one category, but a box or a meaningful label can communicate that grouping more directly than color alone. Copy and duplicate only a deliberate selection, then inspect the messages and identifiers in the result. The common source history remains the place to reconsider a bulk operation.

## 14. Explain both outcomes

Pause and build the successful request interaction, then add a validation-error branch. Include one activation and one note that explains a real assumption. Inspect a participant and a message through their visual controls, and apply one shared style to a verified selection. Your success check is that someone can trace the successful and unsuccessful paths and identify who performs each step. Use the supplied source examples to check specialized arrow and lifecycle syntax separately.

## 15. A readable interaction is a precise explanation

Use participants for the actors and systems, messages for their interactions, and lifecycle or fragment constructs only when they express an important distinction. Review identity, endpoints and branch conditions before tuning appearance. Keep the source available for precise syntax and reference examples. We will reuse this same portal behavior when comparing capabilities, types, architecture and workflows in the following modeling lessons.
