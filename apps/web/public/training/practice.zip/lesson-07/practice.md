# Lesson 07: Reports and task check-in

Prepare an accurate check-in for each person without sending anything.

Start and recorded-result sources are chapter snapshots from the demonstrations. Open the appropriate diagram type, then paste the source. A snapshot is plain PlantUML, not a replacement for a connected portable document or its history. Follow the video for UI-only and local-state workflows.
