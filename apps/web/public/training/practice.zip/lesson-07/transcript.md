# Lesson 07: Reports and task check-in

## 1. Choose a report for the question

Reports turn the plan into a focused explanation for a person or a decision. This lesson covers eight report types, shared scope controls, coordinator presets, explicit progress observations and useful output. We will distinguish current status, forecast, workload, critical path, milestones, baseline changes and historical progress. The same dataset can answer different questions, so choose the question before formatting the result. Nothing in this lesson automatically sends a message to your team.

## 2. Prepare a person-specific task check-in

Task check-in prepares a focused follow-up for each selected person. Choose the reporting date and reply-by date, then inspect the assigned tasks and questions. Ongoing includes unfinished work that has started, is past planned finish or has positive progress, with unresolved dates controlled separately. Check who will receive which tasks, especially for shared or unassigned work. The app prepares text for you to copy; it does not send email or a message automatically.

## 3. Review workload and assignment coverage

Resource workload and assignment coverage answers who is carrying the work and what is not assigned clearly. Inspect allocation, capacity and any unresolved scheduling information before using a summary as evidence that the team is feasible. An unassigned task can disappear from a person-only view while remaining important to delivery. Compare the report with the resource panel when investigating a conflict. A useful coordinator summary includes that missing ownership rather than making the plan look tidier by omission.

## 4. Report the progress forecast

The Progress forecast report uses the same calculations and saved remaining-work assumptions as the forecast view. Its as-of date begins with the saved forecast date or today, and changing it produces a report scenario. Explain which date and assumptions the report uses. A projected finish is not an observation that the source has already been rescheduled. Compare planned and forecast work, then trace a relevant cause before sharing a conclusion.

## 5. Critical path and schedule sensitivity

Critical path and schedule sensitivity helps identify work with little or no scheduling flexibility in the modeled network. Inspect the dependency chain and close to critical threshold. Near-critical work deserves attention even when it is not the single most restrictive path at this moment. This report depends on the modeled schedule and its assumptions; missing dependencies can produce a misleadingly comfortable result. Explain the relevant chain and the threshold you chose rather than treating a highlighted task as an unexplained risk label.

## 6. Milestone and delivery outlook

Milestone and delivery outlook focuses the conversation on delivery events. Trace a milestone back to the work that drives it and identify the status or forecast facts behind any concern. A milestone marker is not a block of effort, and a highlighted deadline is not proof that the date is achievable. Use the report to make a specific conversation possible: which delivery event is affected, which work matters, and what decision or clarification is needed next.

## 7. Progress and due-date outlook

Progress and due-date outlook summarizes completion and due-date status. Read the as-of date, task scope and treatment of unresolved schedules before interpreting totals or charts. A percentage may summarize reported work without explaining whether the remaining effort is realistic. Compare the detailed tasks when an aggregate looks surprising. Use notes or a follow-up to clarify uncertainty rather than hiding it behind a compact report that appears more precise than the plan actually is.

## 8. Record explicit historical observations

Historical burndown and burnup requires at least two explicit observations and stable aliases for every task and milestone. Previewing a report does not create history. Record a snapshot for the ninth of November, update the reported progress, then record another for the sixteenth. Select the historical report and compare fixed baseline scope with current scope over time. Explain whether scope changes belong in the comparison. Save the document to retain these pinned observations in the portable file; they are separate from undo history.

## 9. Explain changes since a saved baseline

Changes since baseline compares the current plan with a retained reference. Save a baseline before making the change you want to discuss. We will then update Backend's completion and inspect the baseline report. A useful review identifies what changed and why, rather than presenting every task as newly added because the reference was not the intended plan. Keep this report separate from a historical progress chart: a baseline comparison and a sequence of dated observations answer different questions.

## 10. Coordinator and delivery presets

Coordinator summary and Delivery outlook presets begin with broader scope than a person-specific check-in. Compare the two presets and inspect which tasks, milestones and unassigned work they include. A preset is a starting configuration, not a reason to skip review. Canvas filters do not silently define the report scope. Check dates and recipients again after switching report type, especially when the result will be used to coordinate work across several people.

## 11. Customize content without changing facts

Content and layout controls decide how much supporting material to include. Notes, task links, unresolved schedules, milestones, compact output and charts serve different audiences. Introduction and sign-off fields help the prepared message fit your context. Keep the underlying facts and uncertainty visible while choosing the presentation. A compact result should not imply that unassigned or unresolved work has ceased to exist. Inspect the complete preview before copying a message or downloading a report.

## 12. Keep report scope independent of canvas filters

Filter the canvas to Alice and note that this is a view choice, not a deletion. Open Reports and explicitly choose all tasks for the report as of November sixteenth. Select Sam as the preview recipient and set a reply date of November eighteenth. Backend remains in Sam’s report even though the canvas is filtered to Alice. Change the compact layout and check the same task and recipient facts again. The report controls determine its scope; they do not silently inherit the canvas filter or change the authored plan.

## 13. Refresh after the plan changes

Reports capture a view of the plan. If the source changes while a report is open, the app warns that the plan changed and offers Refresh report. Do not share a stale preview as though it were a current calculation. Close the report, change a progress value, reopen and inspect the result; when working concurrently, look for the stale warning and refresh explicitly. The useful habit is to check the report's date, scope and freshness immediately before using its output.

## 14. Refresh a report changed by another editor

Keep a report open while another editor changes the shared plan. The second browser updates Backend progress from ten to forty percent. The open report now warns that the plan changed, and its output controls are disabled until you refresh. Read that warning and choose Refresh report, then inspect the updated report before copying or downloading it. This prevents an older captured report from being mistaken for the current plan. The change is real collaboration traffic between the two training browsers.

## 15. Copy or export after reviewing

Use the supported output controls to copy or download the prepared result after reviewing it. Check a pasted or exported example rather than assuming that rich text, charts and plain text will look identical in every destination. Keep links and recipient-specific content appropriate for the audience. The app does not send these check-ins, so the final choice of recipient and delivery channel remains with you. Save relevant progress observations separately when they should remain part of the document.

## 16. Choose evidence for a delivery conversation

Pause and prepare a check-in for each assigned person, then a coordinator view that includes unassigned work. Explain a critical or near-critical chain, inspect a milestone and compare progress with forecast. Record two explicit observations and explain the scope of the historical chart. Finally, save a baseline, make one clear change and identify it in the baseline report. You have succeeded when each result answers a distinct question and its date, scope and assumptions are understandable.

## 17. A useful report makes its limits clear

Choose the report for the question, then check dates, scope, assumptions and freshness. Keep current status, forecast, baseline changes and historical observations distinct. Review the output before copying or exporting, and remember that preparing a message does not send it. The following lessons return to scope structure and connected diagrams, so the work behind these reports remains organized and traceable as the project evolves.
