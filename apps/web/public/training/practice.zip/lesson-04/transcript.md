# Lesson 04: Dependencies and calendars

## 1. Explain the dates with rules

A useful schedule explains why work begins when it does. In this lesson we will connect tasks, compare dependency relations, add a lag, and adjust working calendars. We will also distinguish authored timeline scale from preview magnification. The customer portal plan gives us a small example that is easy to inspect. Keep checking the source as you change the rules: an arrow's appearance is less important than the start or end condition it represents.

## 2. Create a dependency explicitly

Start with independently dated tasks. Use Add dependency to choose a predecessor and successor, then choose which endpoint of each task participates. We will connect Research's end to Design's start. Check the generated statement and the resulting dates. A dependency is a rule, not merely an annotation on the drawing. If you connect the wrong pair, inspect or remove the link rather than trying to compensate by dragging unrelated tasks into a convenient-looking arrangement.

## 3. Compare four endpoint relations

A start can follow another task's end or start, and an end can follow another task's end or start. These four relations express different constraints. We will compare valid source examples, checking the relationship shown by the inspector after each one. The end-constrained examples keep an explicit start so the duration has a clear basis. Return to the original end-to-start rule after comparing the endpoints. Do not choose a relation just because its arrow looks tidy. State which event constrains the work and verify that the resulting dates express that requirement.

## 4. Add a lag and read it correctly

A dependency can include an offset. Open the Research-to-Design link and set a lag of two days after the predecessor's end. For the statement N days after A's end, the candidate start is A's last day, plus one, plus N. If that candidate is closed in the working calendar, the start moves to the next working day. This is different from treating the predecessor's last day as the successor's first day. Read the authored expression and calculated date together, especially across a weekend.

## 5. Verify lag across a closed weekend

The zero-lag start-at-end rule places Design on Friday, the sixth, in this working calendar. In the source, change the rule to one day after Research ends. The candidate date falls on a closed Saturday, so the working calendar advances Design to Monday the ninth. Hover over Design to read its resulting dates and compare them with the explicit source rule. Closed-day advancement must follow the same working calendar used to interpret the schedule.

## 6. Reconnect and explain a link

The dependency inspector lets you change the endpoint tasks as well as the relation. In a practice copy, redirect the predecessor from Research to Build and inspect what the app permits. Avoid creating a cycle: a task cannot ultimately depend on itself. Line style, color and an optional note communicate the dependency's meaning, but they do not replace the scheduling rule. Return to the intended pair or delete an unwanted link, then use Undo to reconsider the change if necessary.

## 7. Compare only-task and cascade movement

In this fixed-task example, choose Only task and retain Build’s authored start date. Move Design by one day and verify that Build keeps its start. Undo that edit before comparing the other policy. Choose Include dependents and move Design again; the connected Build task now moves with it. One shared Undo restores the complete cascade as a single source change. Relative start statements express their own scheduling rules, so check the authored rules as well as the movement preference.

## 8. Convert an explicit start rule in source

Use separate task declarations and scheduling statements to make this rule easy to review. Replace Design’s fixed start statement with a start at Research’s end, and check the current preview. The relative rule records why the start follows the earlier task. Replace it with the original fixed date and verify that the source and preview return to the starting state. Hover over Design to read the resulting task date after the source edits. Keep property inspectors closed during these rule replacements.

## 9. Reconnect and remove a dependency

Select the Design to Build dependency and inspect its predecessor and successor. Change the predecessor to the independent Review task, then check the generated reference and the current schedule. Reconnecting an endpoint changes which work constrains Build; it is not just moving an arrow for appearance. Delete that link in the disposable copy and verify that the old relation is no longer authored. Inspect dates after removing a constraint so the resulting schedule remains understandable.

## 10. Inspect a problematic dependency change

In this disposable example, try making Design depend on Build while Build already depends on Design. That request creates a cycle rather than a meaningful order of work. Inspect the validation feedback and the authored result before continuing. Do not try to repair a cycle simply by dragging bars until they look separated. Restore the known good source and verify the current preview, then choose dependencies that express a consistent direction of work.

## 11. Choose the working calendar

Open Calendar and schedule. The project start and closed weekdays are authored settings. This example closes Saturday and Sunday, so five working days can span a longer calendar interval. Compare the weekday controls with the source declarations. Changing the calendar changes the schedule calculation, not just the picture. Use a calendar that reflects the work being planned, and explain exceptions rather than silently changing every task's duration to compensate for holidays or non-working periods.

## 12. Add a dated exception

Use Add exception to mark a specific day or range as closed or opened. We will close the tenth of November. Set the From and To dates to that day and leave the state closed, then choose Apply. Inspect the source and the affected task dates. An opened exception can represent a special working day, while a closed exception can represent a holiday. These are changes to the shared plan, so include the assumptions when reviewing the schedule with other people.

## 13. Pause one task instead of the whole calendar

Sometimes the whole project is working, but a particular task cannot proceed on a certain day. A task pause is different from closing that day for every task. Inspect Design's pause controls and compare a task-specific pause with the calendar exception we just created. Use the narrowest rule that expresses the real constraint. After applying a pause, check the effective end date and any dependent work; a correct local change can still move the overall delivery.

## 14. Timeline scale and preview zoom

The Timeline scale control changes the authored time axis: daily, weekly, monthly, quarterly or yearly. Preview zoom only magnifies the current drawing. Choose weekly scale and apply it, then compare the source. Use this distinction when preparing a long-range view for stakeholders. A monthly overview may be useful for a programme, while daily detail is useful for short work. Neither choice changes the task effort simply to make the diagram look smaller.

## 15. Highlights, labels and filtering

Use calendar and display settings for highlights, title, header, footer and caption. Highlighting a deadline makes it easier to discuss, but it does not create a dependency or promise that the date is achievable. Diagram filters can hide work from the canvas while leaving the source intact. Legend labels explain colors for the reader. Keep these presentation choices consistent with the scheduling facts, and avoid using color alone as the only way to convey a critical distinction.

## 16. Name a color in the legend

The blue Research task supplies a color for the legend. Open Legend labels and name that color Discovery work. Apply the label, then reopen the dialog to verify that it was retained. A legend explains the visual meaning of a color; it does not change a task dependency. Canvas filters and report scope remain separate choices, as shown in the reporting lesson.

## 17. Explain a weekend and a holiday

Pause and create an end-to-start dependency with a two-day lag. State the predecessor's last day, calculate the candidate start using the plus-one rule, and then account for closed days. Add the November holiday and compare the calculated result. Switch to weekly timeline scale, then use preview zoom without editing the source. Your answer should explain each movement with a rule, rather than simply report that one bar became longer or moved to the right.

## 18. Rules first, picture second

You can now create and inspect dependencies, distinguish their endpoints, and account for lag and closed days. You can express project-wide calendar exceptions separately from task pauses, and choose a useful timeline scale without confusing it with magnification. Keep the source and calculated dates together when reviewing a change. The next lesson adds people and capacity, because a plan also needs to explain who is available to perform the work.
