# Lesson 09: Documents and connected diagrams

## 1. One document, several views

A portable document can contain several diagrams. Connected WBS and Gantt diagrams answer different questions about the same work: what belongs in the project, and when that work happens. In this lesson we create the schedule from a breakdown, navigate between members, inspect linked details, and save the document. Keep a distinction between a separate open tab and a diagram that belongs to the same portable document.

## 2. Create a connected schedule

Begin with the customer portal breakdown. Open Plan and choose Create Gantt chart from WBS. Review the document name and project start date before creating it. The application creates a schedule and retains the WBS as a member of the same document. This is a useful starting point, but a work breakdown does not supply every scheduling decision. Review task duration, ordering, resources and dependencies before treating the generated schedule as a commitment.

## 3. Navigate document members

The document navigator lists the diagrams that belong together. Select the WBS member to review structure, then the Gantt member to review the schedule. These are different sources, even though the linked work connects their meaning. Changing the selected diagram is navigation. It does not duplicate the work or create another schedule. Keep the navigator visible while learning the document so you can recognize which member you are editing.

## 4. Inspect the linked work

Return to the WBS and select a work item. Its inspector provides the supported work details and linked Gantt task control. Follow a link when you want to inspect the corresponding schedule item, and check the destination before editing dates. A relationship between diagrams does not mean every line of their source is identical. Structure and schedule retain their own responsibilities. Review shared details deliberately, and avoid creating an unrelated duplicate task simply because you cannot see the other member.

## 5. Review coverage before adding or deleting

As a project grows, compare the work represented on each side. A new WBS item may still need a scheduled task. The Plan command can add missing WBS tasks to the linked Gantt chart, while existing links help avoid duplicating covered work. Review the coverage and deletion choices rather than assuming that removing a shape should remove every related object. Return to the breakdown and verify that the missing-task count is zero; the existing work is not duplicated.

## 6. Delete a WBS item and keep its schedule

Delete Requirements from the WBS in a disposable connected copy. The linked-work dialog explains which Gantt task is affected and offers a deliberate choice. Choose Keep Gantt tasks, then inspect both members. Requirements is gone from the breakdown, while its scheduled task remains with its dates and assignments. Review the resulting coverage rather than assuming a deletion on one side must remove useful work everywhere.

## 7. Delete both linked counterparts

Repeat the small deletion in a fresh connected practice copy, but this time choose Delete in both diagrams. Check that Requirements is removed from the WBS and from the schedule. This option has a wider effect than keeping the counterpart, so inspect the affected work before accepting it. Use separate disposable copies to learn the two outcomes, and preserve a saved project before a real cleanup.

## 8. Add missing scheduled work to WBS

New work can also begin in the schedule. Add Training review as a Gantt task, then inspect the command for missing Gantt work in the linked WBS. Add the counterpart and inspect the breakdown. Review its placement and meaning before treating the generated node as a finished scope decision. Coverage helps find missing counterparts; it does not decide how you should organize the project.

## 9. Link existing work and navigate its counterpart

Create an unlinked Acceptance slot in the schedule of this disposable connected project. Add Acceptance review independently to the work breakdown structure. Select that node and choose the existing Acceptance slot as its linked Gantt task. Open the linked task to verify that counterpart navigation reaches the intended scheduled item. Check that coverage reports no unlinked items after the repair. Save the portable document with its repaired mapping; linking existing work should not create a second scheduled task.

## 10. Save the portable document

Save the containing document as a portable pumlu file. The document holds its member diagrams and their links, so it is the appropriate handover when another person needs the connected project. Exporting one member as plain Plant UML source serves a different purpose and does not replace the whole document. Reopen the saved practice document and verify that both members remain available. Keep an untouched practice copy before experimenting with imports, member removal or link changes.

## 11. Import and rename a member diagram

Import the plain Sequence source into the connected document. Check the new member and its source before renaming it Portal request flow. A member name helps people navigate the document, while aliases inside that diagram identify its modeled objects. Save the portable document after checking the imported member alongside the existing WBS and Gantt views. Importing a plain source diagram does not automatically create semantic object links to the existing members.

## 12. Remove a disposable member

A document member can also be removed from the containing project. Import the disposable Sequence example, inspect the three members, then choose Delete for that imported diagram and read the confirmation. Verify that the WBS and Gantt members remain available. This is a document member operation, distinct from deleting a linked WBS work item or its scheduled counterpart. Keep a saved copy before reorganizing a real project, and check the intended member name before accepting removal.

## 13. Connect scheduled work to a model object

A document can also record object connections across different diagram types. Import the request Sequence diagram and connect the scheduled Backend work to its API participant using the compatible link controls. The link labeled implements records this connection in the document; the diagram sources retain their existing arrows. Inspect the connection and its resolved endpoints, then save the portable document. Keep these object connections distinct from the WBS to Gantt scheduling counterparts and from an external web link.

## 14. Reconcile a small project

Pause and create a connected document from the practice breakdown. Navigate to both members and identify the corresponding work. Add a missing work item, inspect coverage, and schedule it deliberately. Rename a member so its purpose is clear. Save a portable copy, reopen it, and check that the members and links remain available. Success means you can distinguish separate files from members of a connected document and explain both the structure and the schedule.

## 15. Keep connections intentional

A connected document combines distinct diagrams with explicit links. Use WBS to organize work and Gantt to schedule it. Inspect coverage when either side changes, review deletion consequences, and save the portable document when handing over the full project. In the next group of lessons, the same habit of checking identity and relationships will help you maintain the software models as well.
