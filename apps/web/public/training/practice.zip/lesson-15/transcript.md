# Lesson 15: Editor assistance and navigation

## 1. A deliberate editing routine

The source editor offers navigation, completion and diagnostic tools that help maintain a diagram as it grows. Use them to find an element, understand an error and review a proposed repair. An offered completion or quick fix still needs your judgment. In this lesson we locate commands, search the source, inspect an intentional error, and connect editor assistance to the semantic review workflow.

## 2. Find an available command

Open Commands and type a few words describing the action you need. The palette filters available commands and shows their current context. Use the arrow keys to choose an entry and Enter to run it. Read disabled commands in context: the diagram type, selection or permission may explain why they are unavailable. Escape closes the palette when you are only looking up a command.

## 3. Find work by meaning

Use the diagram outline when you want to navigate by element rather than by line number. Search for a meaningful label and use the type filter to narrow a large model. Selecting a result connects navigation to the diagram and source. Keep aliases and labels clear so search results remain understandable. For exact text, use the source editor search instead; a text match and a semantic element are related but different ways of locating information.

## 4. Read the preserved-source explanation

A source-first workflow also supports constructs outside the visual editors. This state diagram renders successfully, while Issues identifies four preserved source lines. Open Preserved source to inspect the explanation. Preserved means the source remains intact; it does not promise that the current visual editor understands every statement. Edit this example in the source, verify the current preview, and use a supported diagram type when you need its dedicated visual controls.

## 5. Dock the outline and navigate a match

Open the diagram outline and search for Design. Dock the outline so the match list remains alongside the editor. Select the Design task result to move to its source statement and reveal the corresponding object. Check the task identity before editing when several results share a label. Docking and searching change your workspace navigation; they do not change the authored schedule. Use the close control when you need the full drawing area again.

## 6. Search the authored statements

Click in the editor and use the search shortcut to find Design. Source search is useful for exact labels, aliases and repeated syntax. Check every replacement before applying it broadly, especially when a word also appears in notes or display text. Semantic rename is the better route when the intent is to rename a recognized referenced element. After a change, inspect both the declarations and the references that should follow it.

## 7. Preview source formatting before applying it

Open Format source and read the preview before applying a text change. This aliased task example is not supported by the formatter, so the dialog explicitly reports that nothing was changed. For a supported simple task example, inspect how the proposed formatting removes leading statement whitespace. Apply the reviewed result, then verify that the task statements remain and the diagram preview is current. Use shared Undo and confirm that the original indentation returns as one undoable change. Leave unsupported syntax unchanged and keep formatting separate from semantic edits.

## 8. Understand an intentional error

We will deliberately replace a task duration with an invalid word in this disposable example. Wait for the diagnostics, then use Next error and Explain error to inspect the reported location and guidance. Keep the last good preview in mind while a new render is invalid; a visible picture does not mean the current source has succeeded. Use Go to line to visit the reported statement, then repair the authored statement and wait for Preview current again.

## 9. Verify the repaired result

The repair is to restore a numeric duration. Return to the source and replace the invalid word with five, then wait for Preview current. Check that the diagnostic clears and that the expected task is visible. When a quick fix is offered, inspect its proposed source change and the resulting diagnostics before applying it. Safe batch fixes can help with independent changes, but do not combine ambiguous alternatives simply to make the warnings disappear.

## 10. Use completion and semantic references

Completion helps insert supported syntax and known identifiers at the cursor. Review the selected suggestion before accepting it, because the right text still depends on the surrounding statement. Semantic highlighting and references help you follow a recognized identity through the source. Use rename for a recognized symbol, review its proposed scope, and verify the rendered result. If a construct is not understood semantically, inspect and edit its text deliberately instead of assuming every mention will be updated.

## 11. Rename a referenced identity

Place the cursor inside the design alias and invoke Rename. The preview distinguishes the declaration from references and leaves comments and notes unchanged. Enter interaction underscore design as a compact alias without spaces, then inspect the proposed edits. Apply the rename and verify the declaration and downstream dependency. A semantic rename changes the recognized identity consistently; it is different from replacing every matching word in the file.

## 12. Accept a completion deliberately

Completion proposes existing tasks and supported statements at the cursor. In this disposable example, begin a bracketed reference with Des and open the completion list. Inspect the Design suggestion before accepting it, then complete the statement to set progress to twenty five percent. Check that the accepted reference uses the task alias and that the current preview agrees. Use completion to reduce typing, then read the result rather than assuming a suggestion understands the whole model.

## 13. Preview and accept a safe repair

Remove the closing delimiter in a disposable copy and inspect the resulting diagnostic. Open the available source fixes and read the proposed replacement. Apply the closing delimiter repair, then wait for the current preview and verify that the task source remains intact. A safe repair addresses this recognized issue; it does not certify that the plan is correct. Use Undo if the result does not match your intention, and keep ambiguous alternatives separate.

## 14. Review Sequence changes as groups

Sequence diagrams also support semantic change review. A participant edit and its related messages may form changes that should be accepted together. Use Version history, select the baseline, and inspect Review alongside Source and Rendered. Select confirmed related groups, validate the combined result and review replacement warnings before applying. If a change remains unclassified, use Source review. The history lesson demonstrates the same workflow and how to export review evidence.

## 15. Accept a grouped Sequence proposal

Keep the current Sequence diagram as the review base and import a proposed comparison source. The proposal renames the Web app display label and changes its final confirmation message. Inspect both recognized groups, select them together and review their combined validity. Apply the two selected groups, then verify that both the participant label and message changed in the working source. The original alias and message endpoints remain consistent. This is grouped acceptance of a proposed edit, not a blind replacement of the whole file.

## 16. Repair and review a practice copy

Pause and locate a task using the outline, then find its exact statement using source search. Introduce one invalid duration in the practice copy, navigate to the error, explain it and repair it. Try completion in a supported statement and inspect the suggestion before acceptance. Rename a referenced element with the semantic workflow and review the result. Success means you can explain why the source is valid and why the model still expresses your intent.

## 17. Assistance supports judgment

Use editor assistance to reduce searching and make changes easier to inspect. Read diagnostics rather than guessing from the picture, review proposed repairs and verify the current render. Keep semantic tools and exact source review available together. Next we will preserve known states in history and use comparisons to make changes understandable to another reviewer.
