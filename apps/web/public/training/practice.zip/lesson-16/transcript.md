# Lesson 16: History and change review

## 1. Review before replacing

Version history gives you named checkpoints and ways to compare them with the current working copy. A checkpoint is useful before a risky edit, a review or a handover. We will name a version, change a duration, compare the result as source and as a drawing, export a review report, and recover a known state. History is useful evidence, but it still needs a deliberate retention and saving routine.

## 2. Create a named checkpoint

Open File and Version history. Enter Before review as the new version name and create the version. Use names that describe a decision or a state, rather than several indistinguishable copies called final. Close history and continue editing the working copy. Creating a checkpoint gives you a comparison point; it does not prevent later changes. Save the portable document when you want to preserve its retained history in a file.

## 3. Compare the exact source

Start from a named checkpoint and change Design from five days to seven. Reopen history and select Before review. Compare it with the current working copy, then choose Source. Read the changed statement and its surrounding context. A text difference tells you exactly what changed, including edits that may have little visual effect. Use it when a semantic summary is incomplete or when specialized Plant UML syntax needs careful inspection.

## 4. Compare the drawing

Switch to Rendered to inspect the visual consequence of the same source change. Check task endpoints, dependencies and nearby work rather than judging only the changed bar. A rendered comparison helps a reviewer connect the edit to what people will see. Return to Source when a highlight is ambiguous. The two comparisons support each other: the picture explains the effect, while the source identifies the authored statement.

## 5. Review meaningful groups

Choose Review for a semantic summary of recognized changes. Confirmed groups can be selected together and reviewed as a combined result. Related changes may need to stay together to remain valid. Unclassified changes require source review, and selecting a group is not the same as applying it. Check the proposed result and any replacement warning before accepting selected groups into the working copy. If the working copy changes during review, review again before applying.

## 6. Export review evidence

A review report records the comparison for someone who needs to inspect the changes. From Review, export the report and keep it alongside the document for this exercise. A selected patch is a more focused artifact containing selected changes; select and validate those groups before exporting it. Neither artifact replaces the portable project. Explain the baseline, the compared working copy and the intended scope so the recipient knows what the evidence describes.

## 7. Export and apply a selected change

Create a named review base, then change both the Design duration and the title in this disposable copy. In Review, select only the confirmed duration group and export its selected patch. Read the replacement warning carefully: applying this selection from the review base removes unselected differences from the working copy. Confirm that consequence only for this exercise, then apply the selected group. Verify that Design remains seven days while the unselected title change is removed. This is why selection, validation and replacement confirmation belong together.

## 8. Review a connected document against its saved baseline

Save a connected document before creating the comparison baseline. Change the Requirements label in the work breakdown structure, then open the document navigator review. Inspect which member diagrams and connections differ from the last successful save. A document review gives the connected context, while a single diagram history comparison answers a narrower question. Export the review report and keep it alongside the portable practice document. Saving a new baseline is a deliberate next step after reviewing the change.

## 9. Name, pin and retain deliberately

Select a checkpoint and inspect its name, pin and baseline controls. Rename a checkpoint when a clearer description will help the next reviewer. Pin a state you need to retain, and choose a baseline deliberately for comparisons that use it. Retention still depends on document settings and the history budget. Browser recovery and a saved portable document are different safeguards, so keep a saved copy before major experiments or clearing browser data.

## 10. Restore a known checkpoint

Now restore a known checkpoint in this disposable practice document. Start with Before review, change Design to seven days, and select the earlier checkpoint in history. Choose Restore this version and read any confirmation. Return to the source and verify that Design is five days again, then inspect the current preview. A restore is an authored change to the working copy, so save the recovered result when it is the state you intend to keep.

## 11. Recover and explain a change

Pause and save a named checkpoint. Change a task duration and one label, then compare the working copy using Source, Rendered and Review. Export a review report. Locate the checkpoint you would restore, read the confirmation carefully, and restore it in your disposable practice document. Verify the recovered source and drawing, then save the result. Success means you can explain both what changed and exactly which state you recovered.

## 12. Preserve the reason for a change

A useful review has a clear starting state, a clear proposed result and evidence that connects the two. Use named checkpoints, complementary comparison views and explicit acceptance. Preserve the portable document and review evidence when handing work over. The next lesson extends this discipline to concurrent collaboration, where permissions, room lifetime and the difference between shared work and local history also matter.
