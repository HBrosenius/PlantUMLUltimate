# Hyperlink practice reference

This disposable reference page is used in lessons 03 and 20. To repeat the exact local URLs, serve this folder:

```sh
python3 -m http.server 5230 --bind 127.0.0.1 --directory output/course/learner-pack/reference-material
```

Use `http://127.0.0.1:5230/requirements.html` in a task or diagram link. Review the browser confirmation, cancel once, then open the reference and return to the original diagram. A static exported SVG retains links but does not include the editor's confirmation dialog.
