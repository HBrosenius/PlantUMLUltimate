# Lesson 01: First launch and workspace

## 1. Find your way around

This lesson introduces the workspace you will use throughout the course. We will create a diagram, choose an editing view, navigate the canvas, and find the settings that make the editor comfortable to use. The example is a customer portal launch. You do not need Plant UML experience yet. Your first goal is to recognize where a command belongs and distinguish a change to your view from a change to the document.

## 2. Choose the right diagram

The diagram chooser offers seven diagram types. Gantt is for schedules, WBS for the breakdown of work, and Activity for workflows and decisions. Sequence explains interactions over time. Use Case connects actors to capabilities, Class describes types and members, and Component describes software structure. Choose a type for the question you want to answer, rather than trying to put every kind of information into one picture. The visual tools and inspectors adapt to your choice.

## 3. Blank, starter or example

Start with controls how much source is provided. Blank gives you a minimal document; a simple starter gives you a small editable example. The example route offers more realistic starting material. Give the diagram a useful name before choosing its type. We will create a Gantt starter called Portal practice. The name helps you find the diagram later, while saving still chooses the destination file. A starter is a beginning you can change, not a locked template.

## 4. Use the command categories

The ribbon groups commands by purpose. Edit contains history, selection and source operations. Insert creates objects for the current diagram type. Plan contains scheduling tools for Gantt, and connected-work actions for WBS. View contains navigation, panels and diagram settings. You can collapse the ribbon when you want more room. If a command is unavailable, inspect its context before assuming something is wrong: the diagram type, selection and editing permission can all matter.

## 5. Read command scope on a non-planning diagram

The Plan category is still present when a Class diagram is active. Its message explains that planning tools are for Gantt and work breakdown diagrams. Insert instead exposes the Class editing commands appropriate to this model. A command category can explain its scope without changing the authored diagram.

## 6. Code, Split and Diagram

Code view gives the source editor the workspace. Diagram view gives the picture more room. Split view keeps the two together, which is useful while learning how a visual edit changes the text. Switching views does not rewrite your plan. Compare the same tasks in all three layouts, and return to Split when you want to check both representations. Later lessons will sometimes focus on the diagram for interaction, and sometimes on the source for precision.

## 7. Navigate without changing the plan

Fit adjusts the preview to the available canvas. Zoom changes magnification, and panning changes which part of the drawing you see. These are viewing operations. In a Gantt chart, timeline scale is different: it is an authored setting that changes the time axis in the source. Use the preview controls when a diagram is difficult to see, rather than altering dates or durations to make it fit the screen. You can always return to a fitted view.

## 8. Panels and diagram options

Select a task to open its inspector. An inspector explains the object you selected and provides its supported editing controls. When the panel takes too much space, focus on the diagram or restore Split view using the view buttons. The Diagram options group contains filters and move policy for the Gantt preview. A filter can hide work from the canvas without deleting it from the plan. Close panels when you have finished a task so the workspace stays readable.

## 9. Make the editor comfortable

Open Settings to adjust the app appearance and editing preferences. Light, dark and system themes affect the application. Preview adaptation changes how a drawing is presented in the app, while a diagram theme is part of the diagram's own appearance. Editor font size, tab size, wrapping and line numbers help you read and edit source. Default view and zoom apply to new tabs. Set these for comfort; you do not need to change the project itself to make the interface easier to use.

## 10. Save editor defaults and search the relevant help

Choose defaults for future work in Settings. Set Split as the default view, one hundred percent as the default zoom, two space tabs and the chooser on startup. Apply, reopen Settings and verify those retained values. Search Help for dependency and keep the Gantt-specific reference in view. Application defaults and Help navigation leave this authored plan unchanged.

## 11. Commands and Help

Commands helps when you know what you want to do but cannot remember where its control lives. Search for a familiar action and inspect the available result. Help provides a quick tour, diagram-specific guidance and keyboard shortcuts. Search there when you need an explanation rather than an operation. Learning a few shortcuts is useful, but understanding the command's context matters more than memorizing a long list. The next lesson will use these editing surfaces to make precise changes.

## 12. Save a personal starting point

If you repeatedly create the same kind of diagram, save a personal starter rather than copying an unrelated project each time. File contains Save as starter for preserving a useful starting source. Give it a name that explains its purpose, then find personal starters in the chooser. Review its source, choose Create from starter, and verify the new independent diagram. A starter helps create new work; the portable file is where you keep the specific project's diagrams, settings and retained history.

## 13. Your first workspace exercise

Pause and create a separate practice diagram with a useful name. Switch through Code, Split and Diagram views, then return to Split. Zoom in, pan to inspect another part of the drawing, and use Fit to recover the overview. Find the editor settings and choose a readable font size. Finally, locate a command and its explanation in Help. You have succeeded when you can do those things without changing the diagram source simply to adjust the view.

## 14. A repeatable working routine

Begin with the right diagram type, choose a view for the task, and use navigation controls to see the work clearly. Use inspectors for supported object edits and the ribbon for commands. Keep view preferences separate from authored content, and use Help when the meaning of a control is unclear. In the next lesson you will edit a plan visually and in source, checking that both describe the same result.
