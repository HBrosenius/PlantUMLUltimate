# Lesson 17: Live collaboration

Join as a viewer, demonstrate the permission boundary, then revoke the old links.

Start and recorded-result sources are chapter snapshots from the demonstrations. Open the appropriate diagram type, then paste the source. A snapshot is plain PlantUML, not a replacement for a connected portable document or its history. Follow the video for UI-only and local-state workflows.
