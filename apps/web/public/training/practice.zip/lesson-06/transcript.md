# Lesson 06: Forecasts and schedule scenarios

## 1. Compare a plan with an informed forecast

A plan describes the schedule you authored. A progress forecast asks what current progress and remaining-work assumptions imply about the future. A scenario explores an alternative before you commit it. This lesson keeps those three ideas separate. We will fix a status date, inspect the forecast, investigate a delay and create a named alternative. You should finish able to explain the assumptions behind a proposed change and review its effect before applying it to the plan.

## 2. Turn on forecasting with a fixed status date

Expand Diagram options and turn Progress forecast on. Select the sixteenth of November as the status date so that the example is repeatable. Automatic Today uses the document's forecast time zone, while an explicit date gives a fixed point of reference. Read the status date alongside the task progress values. A forecast based on an inappropriate date can be misleading even if every calculation is internally consistent. Check that enabling this view does not rewrite the authored task statements.

## 3. Read plan and forecast together

Compare the planned and forecast bars. The forecast is not a record that the plan was already changed; it is a calculation based on the current status and assumptions. Follow Backend and the work that depends on it. A delayed predecessor can affect later tasks and the launch milestone. Keep the dependency chain visible instead of reading only one finish date. Before discussing an action, identify which result belongs to the authored plan and which belongs to the forecast.

## 4. Investigate why a finish moved

Use the task and forecast explanations to investigate a changed finish. Low completion, remaining effort, allocation, closed days and dependencies can all matter. Backend has substantial remaining work and a half-time assignment in this example, so a simple calendar glance is not enough to explain delivery. Inspect the task's progress and resource assumptions before changing them. A useful forecast discussion names the cause and the assumption, rather than treating the projected date as an unexplained prediction.

## 5. Open an isolated what-if scenario

Choose What-if scenario from Plan. The base plan is a snapshot used for comparison; the draft is where you explore an alternative. Changing the draft does not immediately change the current plan. Inspect the task controls and the comparison modes before editing. Keep the alternative small enough to explain: for example, change Backend's effort or assignment assumption and observe the consequence. A scenario is useful when its assumptions are explicit, not just when it produces an earlier finish.

## 6. Change a scenario task and update the draft

Select Backend in the scenario task picker. Set its effort to eight days and choose Update scenario to include the task-control edits in the draft. Compare that result with the base. An earlier result is not automatically a better plan: reducing effort requires a reason, such as reduced scope or a changed estimate. Resource changes likewise need a realistic availability assumption. Inspect warnings and the source patch before treating the alternative as a decision.

## 7. Name and retain the alternative

Give the alternative a meaningful name and record why it might work. We will call this one Reduced backend scope and state that the estimate assumes a smaller release boundary. Save it as a new scenario. Named alternatives let you compare proposals without confusing them with the live schedule. Use the saved-scenario controls to reopen or copy an alternative later, and keep its base and assumptions visible when the current plan has moved on.

## 8. Copy a saved scenario and review a changed base

Save a named eight day back end alternative with its assumptions. Set the copied alternative to nine days, change its name and save it as a new scenario against the same base. Reopen the original saved alternative and confirm its eight day task estimate. Now close the draft and change the current plan to eleven days for that task. Reopen the saved alternative and review it against the changed plan, paying attention to the stale base guidance. Keep the current plan unchanged while deciding how to reconcile the alternative. Choose Reconcile with current plan and inspect the overlapping current and scenario task estimates. Explicitly keep the scenario version of the task, then choose Use reconciled scenario. Review the updated source patch; the rebased alternative remains a proposal, and the authored plan still contains eleven days until you apply a reviewed result.

## 9. Review the patch before applying it

Choose Review and apply to inspect the proposed source changes and schedule impact. Confirm that the draft changes only what you intended and that reported problems are resolved. Apply scenario commits the reviewed result to the current plan; closing an uncommitted draft is different. If the plan or capacities changed since the saved base, reconcile the alternative rather than applying a stale proposal blindly. Recheck the actual source after an accepted change.

## 10. Forecast application is also a reviewed change

Enable the forecast and set its status date before opening Apply to plan. Review the proposed task dates and source changes. Opening the review leaves the authored plan unchanged. Accept Apply to plan in this disposable example, verify that the source changes and the preview is current, then save a portable copy of the result. Applying a forecast is a separate decision from enabling its overlay. Keep a recoverable checkpoint before committing a significant reschedule.

## 11. Compare two defensible alternatives

Pause and set the fixed status date in the supplied plan. Identify one task that drives a delayed result and explain its remaining-work and allocation assumptions. Create two alternatives with different, realistic justifications. Name and save them, review each patch and choose only the one whose assumptions you can defend. You have succeeded when you can distinguish the original plan, the forecast and the selected draft, and identify exactly what applying it would change.

## 12. A forecast supports a decision

Use forecasting to make assumptions and consequences visible. Use scenarios to explore alternatives, and review source changes before they become the current plan. Keep status dates, time zones, remaining work and resource capacity explicit. The reporting lesson uses these same facts to prepare useful summaries and check-ins, while retaining the distinction between a calculation, an observation and a decision.
