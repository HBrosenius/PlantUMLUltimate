# Lesson 02: PlantUML and visual editing

## 1. One authored model, two editing routes

The source and the drawing describe one authored diagram. A visual edit changes Plant UML text, and a source edit changes the resulting picture. In this lesson we inspect labels and aliases, make changes from both sides and use shared undo and redo. We will also break one line deliberately, read the diagnostic and repair it while the last valid preview remains available. Work in a disposable practice copy so each experiment is easy to inspect.

## 2. Read a small source document

The start and end delimiters identify the diagram. Each task declaration gives the reader a display label and can provide an alias for later references. In Design as design, the first label is what people read, while the alias gives the source a stable identity to reference. The dependency statements use those identities to connect work. Keep the labels clear, preserve references deliberately and check the current preview after editing.

## 3. Inspect a visual change in source

Select Design in the picture and change its duration from five days to seven. Leave the field to apply the supported inspector edit, then inspect the generated task declaration. The visual control updates the authored source; it does not create a separate hidden schedule. Check following work as well as the selected bar, because a dependency can carry the effect downstream. Keep unrelated labels and statements intact.

## 4. Distinguish field drafts from committed diagram changes

Select Design and keep the original source visible. Type a temporary label while the name field retains focus; the source still contains the committed name. Undo inside that text field and verify that Design returns without a diagram change. Enter a negative duration and leave the field; an invalid value must not replace the last valid schedule. Correct the duration to seven days and verify the committed task statement. Now focus the source editor and use shared Undo to restore five days. Redo returns the committed seven day edit. The focused text field, an invalid draft and the shared diagram history are different states to check deliberately.

## 5. Make the corresponding source edit

Now make the change directly in source. Replace Design’s five day duration with six days and wait for Preview current. Select the same task and inspect its duration field. It should agree with the authored statement and the current drawing. When those views disagree during a failed render, read the status before assuming the visible picture represents the newest source. Source ownership means that both editing routes must preserve the same intended model.

## 6. Change a label without losing its alias

Rename the visible Design task to Interaction design in its inspector. Inspect the task declaration and its dependencies after the edit. The display label changes while the design alias remains available to the connected statements. A label edit is different from a semantic alias rename, which updates recognized references and has a preview. Later editor assistance shows that workflow. For now, verify the label, the stable alias and the resulting schedule together.

## 7. Navigate symbol references

Place the caret on a task identifier in a scheduling rule and open its symbol menu. Find references gathers the declaration and its uses without changing the source. Select the declaration to jump to its source line and inspect the scheduling rules that use the same alias. These actions help you inspect the consequences of an edit before renaming or deleting a symbol.

## 8. Use shared Undo and Redo

Change the duration visually, then return focus to the source editor and use Undo. Verify that the duration returns to five days. Redo the edit and verify seven days again. This demonstrates one authored edit history across the visual control and source editor. Be aware of focus: a field can have its own text-editing behavior while you are still entering a value. Inspect the source after undoing a meaningful change, rather than assuming the keyboard action affected the intended edit.

## 9. Read the failed line and last good preview

Replace the duration with the invalid word banana in this disposable copy. Wait for the failed render and read Line eight cannot be drawn. The message identifies the statement, while the drawing retains the last version that worked. Switch to Diagram view, then use Go to line eight to visit the reported source. A visible picture is not proof that the newest text rendered successfully. Check the status, the reported line and the actual statement before choosing a repair.

## 10. Repair the statement and verify

Restore the numeric duration to five days and wait for Preview current. Verify that the task statement is intact and that the error no longer controls the preview. A repair should preserve the model you intended, not merely make the error count smaller. The editor assistance lesson adds error navigation, explanation and proposed quick fixes. The habit is the same: understand the statement, make a deliberate edit and check the current result.

## 11. Practice both routes and recovery

Pause and change the same duration visually and in source, checking that the other view agrees. Rename a display label while preserving its alias and dependencies. Undo and redo a visual edit with focus in the source editor. Finally introduce one invalid duration, read the failed line, use Go to line and repair it. You have succeeded when the source, inspector and current preview agree, and you can explain why a retained picture may be older than the current text.

## 12. Check the authored result

The source holds the authored model, while the picture and inspectors make it easier to understand and edit. Use both editing routes deliberately, preserve identity and references, and verify shared undo or redo in the source. Read render status whenever a change fails. The next lessons apply this routine to tasks, dependencies, people and forecasts so that the schedule remains understandable as it grows.
